<?php

class TrueFalseQuestion extends MultipleChoiceQuestion
{

}