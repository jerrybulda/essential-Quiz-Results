<?php

class MultipleChoiceAnswer extends Text
{

}