<?php

class FillInTheBlankDetailsBlank extends FillInTheBlankSurveyDetailsBlank
{

}