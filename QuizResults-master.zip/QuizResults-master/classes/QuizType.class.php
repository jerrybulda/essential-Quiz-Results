<?php

class QuizType
{
    const GRADED    = 'graded';
    const SURVEY    = 'survey';
}

?>
